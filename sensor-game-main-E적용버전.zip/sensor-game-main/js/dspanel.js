// ══ DSPANEL: 탭 공통 관리 ══

let dsCurrentTab=1;

function dstab(n){
  dsCurrentTab=n;
  document.querySelectorAll('.ds-tab').forEach((t,i)=>t.classList.toggle('on',i===n-1));
  document.querySelectorAll('.ds-tab-content').forEach((t,i)=>t.classList.toggle('on',i===n-1));
  // 각 탭 빌드
  if(n===1)buildTab1();
  if(n===2)buildTab2();
  if(n===3)buildTab3();
  // 탭 전환 후 pv scale 재계산 (특히 pv3가 1280px 그대로 나오는 버그 방지)
  requestAnimationFrame(()=>{ if(typeof scalePvc==='function') scalePvc(); });
}

function initDsPanel(){
  buildTab1(); // 기본 1번 탭

  // ── pv2 초기 설정 적용: 탭2 클릭 없이도 저장된 모든 설정을 미리보기에 반영 ──
  // sgp_display_config → sgp_d2_* 동기화 (새로고침 시 복원)
  try{
    const _cfg=JSON.parse(localStorage.getItem('sgp_display_config')||'{}');
    if(_cfg.d2CourtShow!==undefined) localStorage.setItem('sgp_d2_court_show',String(_cfg.d2CourtShow));
    if(_cfg.d2CourtSize!==undefined) localStorage.setItem('sgp_d2_court_size',String(_cfg.d2CourtSize));
    if(_cfg.d2InfoShow!==undefined)  localStorage.setItem('sgp_d2_info_show',String(_cfg.d2InfoShow));
    if(_cfg.d2InfoSize!==undefined)  localStorage.setItem('sgp_d2_info_size',String(_cfg.d2InfoSize));
    if(_cfg.d2NameShow!==undefined)  localStorage.setItem('sgp_d2_name_show',String(_cfg.d2NameShow));
    if(_cfg.d2NameSize!==undefined)  localStorage.setItem('sgp_d2_name_size',String(_cfg.d2NameSize));
    if(_cfg.d2NameOnly!==undefined)  localStorage.setItem('sgp_d2_name_only',String(_cfg.d2NameOnly));
    if(_cfg.d2MatchNumShow!==undefined) localStorage.setItem('sgp_d2_matchnum_show',String(_cfg.d2MatchNumShow));
    if(_cfg.d2MatchNumSize!==undefined) localStorage.setItem('sgp_d2_matchnum_size',String(_cfg.d2MatchNumSize));
  }catch(e){}
  // buildTab2()를 직접 호출해 탭2 클릭과 동일한 초기화 수행 (단, UI 탭은 전환하지 않음)
  try{ if(typeof buildTab2==='function') buildTab2(); }catch(e){}

  // courtCount 변경 감지 → 2번 탭 경기장 버튼 갱신
  let _prevCourtCount=parseInt(localStorage.getItem('sgp_courtCount')||'1');
  window.addEventListener('storage', e=>{
    if(e.key==='sgp_courtCount'){
      const newCount=parseInt(e.newValue||'1');
      if(newCount!==_prevCourtCount){
        _prevCourtCount=newCount;
        if(dsCurrentTab===2 && typeof buildTab2CourtBtns==='function') buildTab2CourtBtns();
      }
    }
  });

  // resizer2 드래그 시: 3번탭 iframe pointer-events:none으로 mousemove 가로채기 방지
  // + 3번탭일 때 scalePvc 실시간 호출
  const resizer2=document.getElementById('resizer2');
  if(resizer2){
    resizer2.addEventListener('mousedown', function(){
      // iframe 이벤트 차단
      const iframe=document.getElementById('dst3-bracket-iframe');
      if(iframe) iframe.style.pointerEvents='none';

      function onMove(){
        if(dsCurrentTab===3 && typeof scalePvc==='function') scalePvc();
      }
      function onUp(){
        // iframe 이벤트 복원
        const iframe=document.getElementById('dst3-bracket-iframe');
        if(iframe) iframe.style.pointerEvents='';
        document.removeEventListener('mousemove', onMove);
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp, {once:true});
    });
  }
}
