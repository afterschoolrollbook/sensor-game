/* ════════════════════════════════════════════════════════════════
   ds-tab2.js — 2번 탭 (현재경기 VS 화면) 설정 + 미리보기 처리
   ════════════════════════════════════════════════════════════════

   ■ 이 파일이 하는 일
     - 2번 탭 UI 빌드 (경기장 버튼, VS 색상, 폰트, 레이블 크기 등)
     - pv2 미리보기(#pv2) 갱신 — 가운데 패널 VS 화면
     - _tab2Mode 상태 관리 (court_1 | court_2 | random)

   ■ 핵심 함수
     buildTab2()              → dspanel.js dstab(2) 또는 initDsPanel()에서 호출
     _updatePv2ForMode(mode)  → pv2 미리보기 갱신 진입점
                                setup-core.js updatePv2()가 이걸 호출함
     _updatePv2ForCourt(n)    → sgp_display_vs_court_N 읽어서 선수 이름 pv2에 표시
     _broadcastD2Cfg(extra)   → 설정 변경 시 _bc(BroadcastChannel)로 브로드캐스트
                                setup-core.js _bc.onmessage d2_cfg 수신부에서 처리

   ■ 읽는 localStorage 키
     sgp_display_vs_court_N   → 경기장N 선택 경기 (setup-core.js onMatchClick에서 씀)
     sgp_d2_mode              → 경기장 모드
     sgp_d2_*                 → 세부 표시 설정 (크기, 표시여부 등)

   ■ 연관 파일
     setup-core.js → updatePv2() 래퍼, _bc 초기화, onMatchClick, sgp_display_vs_court_N 저장
     dspanel.js    → buildTab2() 호출 타이밍 관리

   ════════════════════════════════════════════════════════════════ */

// ══ DS TAB 2: 현재경기 VS 화면 설정 ══

let _tab2Mode = 'court_1'; // 기본: 경기장 1
let _pv2RandomIv = null;  // pv2 랜덤 순환 인터벌
let _pv2RandomCourt = 1;  // pv2 현재 경기장

function buildTab2(){
  // ── [BUG FIX 2] 탭 전환 시 _tab2Mode가 항상 'court_1'로 리셋되는 버그 수정 ──
  // 저장된 모드를 복원한 뒤 UI 빌드
  try{
    const saved=localStorage.getItem('sgp_d2_mode');
    if(saved) _tab2Mode=saved;
  }catch(e){}
  buildDs2FontPicker();
  buildTab2CourtBtns();
  buildDs2VsColor();
  buildDs2Labels();
  updateDst2();
  _updatePv2ForMode(_tab2Mode);
}

function buildDs2VsColor(){
  const w=document.getElementById('ds2-vs-color-wrap'); if(!w) return;
  const COLORS=[
    {n:'빨강',v:'#e63946'},{n:'흰색',v:'#f0f0f8'},{n:'노랑',v:'#ffd60a'},
    {n:'청록',v:'#4cc9f0'},{n:'초록',v:'#06d6a0'},{n:'보라',v:'#7b2fff'},
    {n:'주황',v:'#ff9f1c'},{n:'검정',v:'#000000'},
  ];
  const saved=localStorage.getItem('sgp_d2_vs_color')||'#e63946';
  w.innerHTML='';
  COLORS.forEach(c=>{
    const sw=document.createElement('div');
    sw.className='ds-swatch'+(saved===c.v?' on':'');
    sw.style.background=c.v;
    if(c.v==='#000000') sw.style.border='2px solid var(--border2)';
    sw.title=c.n;
    sw.onclick=()=>{
      try{ localStorage.setItem('sgp_d2_vs_color',c.v); }catch(e){}
      w.querySelectorAll('.ds-swatch').forEach(x=>x.classList.remove('on'));
      sw.classList.add('on');
      // 미리보기 반영
      const pvVs=document.querySelector('#pv2 .pv2-vs');
      if(pvVs) pvVs.style.color=c.v;
      // broadcast
      _broadcastD2Cfg({vs_color:c.v});
    };
    w.appendChild(sw);
  });
  // 미리보기 초기 반영
  const pvVs=document.querySelector('#pv2 .pv2-vs');
  if(pvVs) pvVs.style.color=saved;
}

function buildDs2Labels(){
  const courtShow=localStorage.getItem('sgp_d2_court_show')!=='false';
  const courtSize=parseInt(localStorage.getItem('sgp_d2_court_size')||'16');
  const infoShow=localStorage.getItem('sgp_d2_info_show')!=='false';
  const infoSize=parseInt(localStorage.getItem('sgp_d2_info_size')||'16');
  const nameShow=localStorage.getItem('sgp_d2_name_show')!=='false';
  const nameSize=parseInt(localStorage.getItem('sgp_d2_name_size')||'80');
  const nameOnly=localStorage.getItem('sgp_d2_name_only')==='true';
  const matchNumShow=localStorage.getItem('sgp_d2_matchnum_show')==='true';
  const matchNumSize=parseInt(localStorage.getItem('sgp_d2_matchnum_size')||'14');

  const el=(id,val)=>{ const e=document.getElementById(id); if(e) e[typeof val==='boolean'?'checked':'textContent']=val; };
  el('ds2-court-show',courtShow);
  el('ds2-court-size-val',courtSize);
  el('ds2-info-show',infoShow);
  el('ds2-info-size-val',infoSize);
  el('ds2-name-show',nameShow);
  el('ds2-name-size-val',nameSize);
  el('ds2-name-only',nameOnly);
  el('ds2-matchnum-show',matchNumShow);
  el('ds2-matchnum-size-val',matchNumSize);

  _applyD2CfgToPv2({courtShow,courtSize,infoShow,infoSize,nameShow,nameSize,nameOnly,matchNumShow,matchNumSize});
}

function buildDs2FontPicker(){
  const w=document.getElementById('ds2-fontpicker');if(!w)return;w.innerHTML='';
  if(typeof TITLE_FONTS==='undefined')return;
  TITLE_FONTS.forEach(f=>{
    const el=document.createElement('div');
    el.className='ds-font'+(S.vs2Font===f.id?' on':'');
    el.style.fontFamily=f.css;el.textContent=f.name;
    el.onclick=()=>{
      S.vs2Font=f.id;
      document.querySelectorAll('#ds2-fontpicker .ds-font').forEach(x=>x.classList.remove('on'));
      el.classList.add('on');
      _applyPv2Font(f.css);
      if(typeof saveCfgNow==='function') saveCfgNow();
    };
    w.appendChild(el);
  });
  // 초기 로드 시 저장된 폰트 pv2에 적용
  const curFont=TITLE_FONTS.find(f=>f.id===S.vs2Font);
  if(curFont) _applyPv2Font(curFont.css);
}

function _applyPv2Font(css){
  ['pv2-p1','pv2-p2'].forEach(id=>{ const e=document.getElementById(id); if(e) e.style.fontFamily=css; });
  const pv2vs=document.querySelector('#pv2 .pv2-vs');
  if(pv2vs) pv2vs.style.fontFamily=css;
}

function buildTab2CourtBtns(){
  const wrap=document.getElementById('dst2-court-wrap');
  if(!wrap) return;

  const courtCount=parseInt(localStorage.getItem('sgp_courtCount')||'1');
  const savedSec=parseInt(localStorage.getItem('sgp_d2_random_interval')||'60');

  wrap.innerHTML='';
  wrap.style.cssText='display:flex;flex-direction:column;gap:8px;';

  // ── 버튼 행 ──
  const btnRow=document.createElement('div');
  btnRow.style.cssText='display:flex;flex-wrap:wrap;gap:6px;';

  // 랜덤 순환 버튼
  const randomBtn=document.createElement('button');
  randomBtn.className='ds-theme-card dst2-mode-btn'+(_tab2Mode==='random'?' on':'');
  randomBtn.dataset.mode='random';
  randomBtn.textContent='🔀 랜덤';
  randomBtn.title='경기장을 N초마다 번갈아가며 표시';
  randomBtn.onclick=()=>_setTab2Mode('random');
  btnRow.appendChild(randomBtn);

  if(courtCount>=2){
    for(let c=1;c<=courtCount;c++){
      const btn=document.createElement('button');
      btn.className='ds-theme-card dst2-mode-btn'+(_tab2Mode===`court_${c}`?' on':'');
      btn.dataset.mode=`court_${c}`;
      btn.textContent=`🏟️ ${c}번`;
      btn.title=`경기장 ${c}의 선택된 경기 표시`;
      btn.onclick=(()=>{const cc=c;return()=>_setTab2Mode(`court_${cc}`);})(c);
      btnRow.appendChild(btn);
    }
  } else {
    const note=document.createElement('p');
    note.style.cssText='font-size:10px;color:var(--text3);margin:2px 0 0;';
    note.textContent='경기장 2개 이상이면 각 경기장 버튼이 표시됩니다.';
    btnRow.appendChild(note);
  }
  wrap.appendChild(btnRow);

  // ── 인터벌 행 (랜덤 모드일 때만 표시) ──
  const ivRow=document.createElement('div');
  ivRow.id='dst2-interval-row';
  ivRow.style.cssText=`display:${_tab2Mode==='random'?'flex':'none'};align-items:center;gap:8px;
    background:var(--card);border:1px solid var(--border);border-radius:8px;padding:7px 11px;`;

  ivRow.innerHTML=`
    <span style="font-size:11px;color:var(--text3);white-space:nowrap;">🕐 전환 간격</span>
    <button id="dst2-iv-minus" style="width:24px;height:24px;border-radius:5px;background:var(--card2);border:1px solid var(--border);color:var(--text);font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;">−</button>
    <div style="flex:1;text-align:center;">
      <span id="dst2-iv-val" style="font-family:'Share Tech Mono',monospace;font-size:18px;font-weight:700;color:var(--text);">${savedSec}</span>
      <span style="font-size:10px;color:var(--text3);margin-left:2px;">초</span>
    </div>
    <button id="dst2-iv-plus" style="width:24px;height:24px;border-radius:5px;background:var(--card2);border:1px solid var(--border);color:var(--text);font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;">+</button>
    <button id="dst2-iv-start" style="padding:4px 12px;border-radius:6px;background:var(--green);border:none;color:#fff;font-size:11px;font-weight:700;cursor:pointer;flex-shrink:0;">▶ 시작</button>
  `;
  wrap.appendChild(ivRow);

  // ── 인터벌 버튼 이벤트 ──
  const STEPS=[5,10,15,20,30,60,90,120,180,300];
  function _getStepIdx(v){ let i=STEPS.findIndex(s=>s>=v); return i<0?STEPS.length-1:i; }
  let _ivSec=savedSec;

  function _applyIv(sec){
    _ivSec=Math.max(5,Math.min(300,sec));
    const el=document.getElementById('dst2-iv-val');
    if(el) el.textContent=_ivSec;
    try{ localStorage.setItem('sgp_d2_random_interval', String(_ivSec)); }catch(e){}
    // 실행 중인 display.html에 즉시 반영
    const payload={type:'sgp_d2_refresh_random'};
    try{ if(typeof _bc!=='undefined'&&_bc) _bc.postMessage(payload); }catch(e){}
    try{ const dw=_getDispWin(); if(dw&&!dw.closed) dw.postMessage(payload,'*'); }catch(e){}
  }

  function _updateStartBtn(running){
    const btn=document.getElementById('dst2-iv-start');
    if(!btn) return;
    if(running){
      btn.textContent='■ 정지';
      btn.style.background='var(--red)';
    } else {
      btn.textContent='▶ 시작';
      btn.style.background='var(--green)';
    }
  }

  // 현재 랜덤 실행 여부 동기화
  const _isRunning=localStorage.getItem('sgp_d2_random_running')==='true';
  _updateStartBtn(_isRunning);

  document.getElementById('dst2-iv-minus').onclick=()=>{
    const idx=_getStepIdx(_ivSec);
    _applyIv(STEPS[Math.max(0,idx-1)]);
  };
  document.getElementById('dst2-iv-plus').onclick=()=>{
    const idx=_getStepIdx(_ivSec);
    const next=STEPS[Math.min(STEPS.length-1, _ivSec===STEPS[idx]?idx+1:idx)];
    _applyIv(next);
  };
  document.getElementById('dst2-iv-start').onclick=()=>{
    const running=localStorage.getItem('sgp_d2_random_running')!=='true';
    try{ localStorage.setItem('sgp_d2_random_running', String(running)); }catch(e){}
    _updateStartBtn(running);
    const payload=running?{type:'sgp_d2_random_start',interval:_ivSec}:{type:'sgp_d2_random_stop'};
    try{ if(typeof _bc!=='undefined'&&_bc) _bc.postMessage(payload); }catch(e){}
    try{ const dw=_getDispWin(); if(dw&&!dw.closed) dw.postMessage(payload,'*'); }catch(e){}
    // pv2 미리보기도 동일하게 적용
    if(running){ _startPv2Random(_ivSec); } else { _stopPv2Random(); }
  };
}

function _setTab2Mode(mode){
  _tab2Mode=mode;
  // 버튼 active 상태 갱신
  document.querySelectorAll('.dst2-mode-btn').forEach(b=>{
    b.classList.toggle('on', b.dataset.mode===mode);
  });
  // 인터벌 행 표시/숨김
  const ivRow=document.getElementById('dst2-interval-row');
  if(ivRow) ivRow.style.display=(mode==='random')?'flex':'none';
  // display.html에 모드 전달
  const payload={type:'sgp_d2_mode', mode};
  try{ localStorage.setItem('sgp_d2_mode', mode); }catch(e){}
  try{
    const dispWin=_getDispWin();
    if(dispWin && !dispWin.closed) dispWin.postMessage(payload,'*');
  }catch(e){}
  try{
    if(typeof _bc!=='undefined' && _bc) _bc.postMessage(payload);
  }catch(e){}
  _updatePv2ForMode(mode);
}

function _startPv2Random(sec){
  _stopPv2Random();
  const courtCount=parseInt(localStorage.getItem('sgp_courtCount')||'1');
  if(courtCount<2){ _updatePv2ForCourt(1); return; }
  _pv2RandomCourt=1;
  _pv2SwitchCourt();
  _pv2RandomIv=setInterval(()=>{ _pv2SwitchCourt(); }, sec*1000);
}

function _stopPv2Random(){
  if(_pv2RandomIv){ clearInterval(_pv2RandomIv); _pv2RandomIv=null; }
}

function _pv2SwitchCourt(){
  const courtCount=parseInt(localStorage.getItem('sgp_courtCount')||'1');
  const courtLbl=document.getElementById('pv2-court-lbl');
  if(courtLbl) courtLbl.textContent=`// 경기장 ${_pv2RandomCourt}`;
  _updatePv2ForCourt(_pv2RandomCourt);
  _pv2RandomCourt=(_pv2RandomCourt%courtCount)+1;
}

function _getDispWin(){
  // step6.js에서 display.html을 window.open한 핸들이 있으면 반환
  try{ return window._dispWin||null; }catch(e){ return null; }
}

function _updatePv2ForMode(mode){
  const courtLbl=document.getElementById('pv2-court-lbl');
  if(mode==='random'){
    // 랜덤: 저장된 실행 여부 확인 후 인터벌 적용
    const courtLbl=document.getElementById('pv2-court-lbl');
    _pv2RandomCourt=1;
    if(courtLbl) courtLbl.textContent='// 경기장 1';
    _updatePv2ForCourt(1);
    updateDst2();
    const isRunning=localStorage.getItem('sgp_d2_random_running')==='true';
    if(isRunning){
      const iv=parseInt(localStorage.getItem('sgp_d2_random_interval')||'60');
      _startPv2Random(iv);
    }
  } else if(mode.startsWith('court_')){
    const c=parseInt(mode.replace('court_',''));
    if(courtLbl) courtLbl.textContent=`// 경기장 ${c}`;
    _updatePv2ForCourt(c);
  } else {
    if(courtLbl) courtLbl.textContent='';
    updateDst2();
  }
}

// 해당 경기장의 선택된 경기를 미리보기(pv2)에 표시
function _updatePv2ForCourt(courtNum){
  const p1el=document.getElementById('pv2-p1');
  const p2el=document.getElementById('pv2-p2');
  const infoEl=document.getElementById('pv2-info');

  // 수동 선택된 경기 확인
  try{
    const manualStr=localStorage.getItem(`sgp_display_vs_court_${courtNum}`);
    if(manualStr){
      const mv=JSON.parse(manualStr);
      if(mv&&mv.p1){
        const _cn=n=>n?n.replace(/^\d+번\s*/,'').replace(/[()[\]]/g,'').trim()||n:'—';
        const _nameOnly=n=>n?n.replace(/^[\d]+-[\d]+\s+/,'').replace(/^\d+번\s*/,'').replace(/[()[\]]/g,'').trim()||n:'—';
        const nameOnly=localStorage.getItem('sgp_d2_name_only')==='true';
        const fn=nameOnly?_nameOnly:_cn;
        if(p1el){ p1el.textContent=fn(mv.p1); p1el.dataset.rawName=_cn(mv.p1); }
        if(p2el){ p2el.textContent=fn(mv.p2||'—'); p2el.dataset.rawName=_cn(mv.p2||'—'); }
        if(infoEl){
          const _ml=mv.matchLabel||(mv.ri!=null&&mv.mi!=null?`${courtNum}-${mv.ri+1}-${mv.mi+1}`:'');
          const _seq = _ml ? _ml.split('-').pop() : '';
          const _hasSeq = mv.label && mv.label.includes('경기');
          infoEl.textContent = (_seq && !_hasSeq) ? `${mv.label||''} · ${_seq}경기` : (mv.label||'');
        }
        // 경기번호 표시
        const matchNumShow=localStorage.getItem('sgp_d2_matchnum_show')==='true';
        const matchLabel=mv.matchLabel||(mv.ri!=null&&mv.mi!=null?`${courtNum}-${mv.ri+1}-${mv.mi+1}`:'');
        const _seq2=matchLabel?matchLabel.split('-').pop():'';
        let mnEl=document.getElementById('pv2-match-num');
        if(!mnEl){
          mnEl=document.createElement('div');
          mnEl.id='pv2-match-num';
          mnEl.style.cssText='font-family:"Share Tech Mono",monospace;font-size:11px;color:var(--accent);letter-spacing:2px;text-align:center;margin-top:4px;';
          const pv2=document.getElementById('pv2');
          if(pv2) pv2.appendChild(mnEl);
        }
        mnEl.style.display=matchNumShow?'':'none';
        if(matchNumShow) mnEl.textContent=matchLabel?matchLabel+' 경기':'';
      }
    }
  }catch(e){}

  // 선택된 경기 없으면 대기 상태
  if(p1el && (!p1el.dataset.rawName)) {
    if(p1el) p1el.textContent='—';
    if(p2el) p2el.textContent='—';
    if(infoEl) infoEl.textContent='';
  }

  // 항상 시각 설정 적용 (기본값 명시하여 항상 적용되도록)
  _applyD2CfgToPv2({
    courtShow:    localStorage.getItem('sgp_d2_court_show')    !== 'false',
    courtSize:    parseInt(localStorage.getItem('sgp_d2_court_size')   || '16'),
    infoShow:     localStorage.getItem('sgp_d2_info_show')     !== 'false',
    infoSize:     parseInt(localStorage.getItem('sgp_d2_info_size')    || '16'),
    nameShow:     localStorage.getItem('sgp_d2_name_show')     !== 'false',
    nameSize:     parseInt(localStorage.getItem('sgp_d2_name_size')    || '80'),
    nameOnly:     localStorage.getItem('sgp_d2_name_only')     === 'true',
    matchNumShow: localStorage.getItem('sgp_d2_matchnum_show') === 'true',
    matchNumSize: parseInt(localStorage.getItem('sgp_d2_matchnum_size') || '14'),
  });
}

function updateDst2(){
  const el=document.getElementById('dst2-match');if(!el)return;
  if(S.matches&&S.matches.length){
    for(let ri=0;ri<S.matches.length;ri++){
      for(let mi=0;mi<S.matches[ri].length;mi++){
        const m=S.matches[ri][mi];
        if(!m.winner&&m.p1&&m.p2){
          el.textContent=m.p1.name+' VS '+m.p2.name;
          return;
        }
      }
    }
    el.textContent='모든 경기 완료';
  } else {
    el.textContent='— VS —';
  }
}

// VS 화면 배경 스타일 설정
function setVsBg(style){
  const BG={
    dark:'#040408',
    gradient:'linear-gradient(135deg,#0a0a1a 0%,#1a0a2e 100%)',
    blur:'rgba(10,10,20,0.95)',
    solid:'#0d1b2a',
  };
  S.vs2Bg=style;
  document.querySelectorAll('.ds2-bg-btn').forEach(b=>b.classList.toggle('on',b.dataset.style===style));
  // 미리보기 반영
  const pv2=document.getElementById('pv2');
  if(pv2) pv2.style.background=BG[style]||BG.dark;
  if(typeof saveCfgNow==='function') saveCfgNow();
  // display.html에 즉시 broadcast
  _broadcastD2Cfg({vs_bg:style});
}

// courtCount 변경 시 외부에서 호출 가능
function tab2RefreshCourtBtns(){
  buildTab2CourtBtns();
}

// ── D2 설정 저장 + broadcast ──
function _saveD2Cfg(){
  const courtShow=document.getElementById('ds2-court-show')?.checked??true;
  const courtSize=parseInt(document.getElementById('ds2-court-size-val')?.textContent||'16');
  const infoShow=document.getElementById('ds2-info-show')?.checked??true;
  const infoSize=parseInt(document.getElementById('ds2-info-size-val')?.textContent||'16');
  const nameShow=document.getElementById('ds2-name-show')?.checked??true;
  const nameSize=parseInt(document.getElementById('ds2-name-size-val')?.textContent||'80');
  const nameOnly=document.getElementById('ds2-name-only')?.checked??false;
  const matchNumShow=document.getElementById('ds2-matchnum-show')?.checked??false;
  const matchNumSize=parseInt(document.getElementById('ds2-matchnum-size-val')?.textContent||'14');
  try{ localStorage.setItem('sgp_d2_court_show',String(courtShow)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_court_size',String(courtSize)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_info_show',String(infoShow)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_info_size',String(infoSize)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_name_show',String(nameShow)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_name_size',String(nameSize)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_name_only',String(nameOnly)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_matchnum_show',String(matchNumShow)); }catch(e){}
  try{ localStorage.setItem('sgp_d2_matchnum_size',String(matchNumSize)); }catch(e){}
  const cfg={courtShow,courtSize,infoShow,infoSize,nameShow,nameSize,nameOnly,matchNumShow,matchNumSize};
  _broadcastD2Cfg(cfg);
  _applyD2CfgToPv2(cfg);
  // sgp_display_config에도 저장 (새로고침 후 복원용)
  if(typeof saveCfgNow==='function') saveCfgNow();
}

const _D2SIZES=[10,11,12,13,14,16,18,20,22,24,28,32,36,40];
function _stepSize(cur,d){
  let i=_D2SIZES.findIndex(s=>s>=cur); if(i<0)i=_D2SIZES.length-1;
  return _D2SIZES[Math.max(0,Math.min(_D2SIZES.length-1,i+d))];
}

function _chD2LblSize(d){
  const el=document.getElementById('ds2-court-size-val'); if(!el) return;
  el.textContent=_stepSize(parseInt(el.textContent)||16,d);
  _saveD2Cfg();
}
function _chD2InfoSize(d){
  const el=document.getElementById('ds2-info-size-val'); if(!el) return;
  el.textContent=_stepSize(parseInt(el.textContent)||16,d);
  _saveD2Cfg();
}
function _chD2NameSize(d){
  const el=document.getElementById('ds2-name-size-val'); if(!el) return;
  const NAME_SIZES=[20,24,28,32,36,40,48,56,64,72,80,88,96,110,120];
  let cur=parseInt(el.textContent)||80;
  let i=NAME_SIZES.findIndex(s=>s>=cur); if(i<0)i=NAME_SIZES.length-1;
  el.textContent=NAME_SIZES[Math.max(0,Math.min(NAME_SIZES.length-1,i+d))];
  _saveD2Cfg();
}

function _chD2MatchNumSize(d){
  const el=document.getElementById('ds2-matchnum-size-val'); if(!el) return;
  el.textContent=_stepSize(parseInt(el.textContent)||14,d);
  _saveD2Cfg();
}

function _broadcastD2Cfg(extra){
  const msg=Object.assign({type:'d2_cfg'},extra);
  try{ if(typeof _bc!=='undefined'&&_bc) _bc.postMessage(msg); }catch(e){}
  try{ const dw=_getDispWin(); if(dw&&!dw.closed) dw.postMessage(msg,'*'); }catch(e){}
}

function _applyD2CfgToPv2(cfg){
  const pvCourtLbl=document.getElementById('pv2-court-lbl');
  const pvInfo=document.getElementById('pv2-info');
  // 상단 경기장 레이블
  if(pvCourtLbl){
    if(cfg.courtShow!==undefined) pvCourtLbl.style.display=cfg.courtShow?'':'none';
    if(cfg.courtSize) pvCourtLbl.style.fontSize=cfg.courtSize+'px';
  }
  // 하단 경기 정보
  if(pvInfo){
    if(cfg.infoShow!==undefined) pvInfo.style.display=cfg.infoShow?'':'none';
    if(cfg.infoSize) pvInfo.style.fontSize=cfg.infoSize+'px';
  }
  // 선수 이름
  document.querySelectorAll('#pv2 .pv2-pl').forEach(pl=>{
    if(cfg.nameShow!==undefined) pl.style.display=cfg.nameShow?'':'none';
  });
  ['pv2-p1','pv2-p2'].forEach(id=>{
    const nm=document.getElementById(id);
    if(nm && cfg.nameSize) nm.style.fontSize=cfg.nameSize+'px';
  });
  // 이름만 표시 (번호 숨김)
  if(cfg.nameOnly!==undefined){
    ['pv2-p1','pv2-p2'].forEach(id=>{
      const nm=document.getElementById(id);
      if(!nm) return;
      const raw=nm.dataset.rawName||nm.textContent;
      nm.dataset.rawName=raw;
      nm.textContent=cfg.nameOnly
        ? raw.replace(/^[\d]+-[\d]+\s+/,'').replace(/^\d+번\s*/,'').trim()||raw
        : raw;
    });
  }
  // 경기번호 표시/크기
  const mnEl=document.getElementById('pv2-match-num');
  if(mnEl){
    if(cfg.matchNumShow!==undefined) mnEl.style.display=cfg.matchNumShow?'':'none';
    if(cfg.matchNumSize) mnEl.style.fontSize=cfg.matchNumSize+'px';
  }
}
